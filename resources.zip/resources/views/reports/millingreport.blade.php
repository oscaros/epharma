
<x-app-layout>
 
 
    <div class="px-4 sm:px-6 lg:px-8 py-8 w-full max-w-9xl mx-auto">
        <h1 class="text-lg font-semibold mb-6">Milling Report</h1>
    @livewire('milling-report', ['filter' => request()->query('filter', 'all')])
    </div>

</x-app-layout>